package com.example.imageswitcher;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    Button next;
    Button previous;
    ImageView iv;
    boolean flag;
    int images[]={R.drawable.pr1,R.drawable.pr2,R.drawable.puneethrajkumar};
    int i=0;
    int j=images.length-1;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        iv=(ImageView)findViewById(R.id.img);
        next=(Button)findViewById(R.id.next);
        previous=(Button)findViewById(R.id.previous);

        flag=true;
        next.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                iv.setImageResource(images[i]);
                i++;
                if(i==images.length-1)
                    i=0;
            }
        });
        previous.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                iv.setImageResource(images[i]);
                j--;
                if(j==0)
                    j=images.length-1;
            }
        });
    }

}

